<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'status',
        'timezone',
        'currency',
        'locale',
        'created_by',
        'legal_name',
        'primary_contact_name',
        'primary_contact_email',
        'primary_contact_phone',
        'principal_address',
        'fiscal_year_start_month',
        'setup_status',
        'setup_completed_at',
    ];

    protected function casts(): array
    {
        return [
            'created_by' => 'integer',
            'principal_address' => 'array',
            'fiscal_year_start_month' => 'integer',
            'setup_completed_at' => 'datetime',
        ];
    }

    public function users()
    {
        return $this->belongsToMany(User::class)
            ->withPivot(['status', 'is_owner', 'last_active_at'])
            ->withTimestamps();
    }

    public function roles()
    {
        return $this->hasMany(Role::class);
    }
}
