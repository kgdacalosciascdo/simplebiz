<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CompanyController;
use App\Http\Controllers\Api\CompanyProfileController;
use App\Http\Controllers\Api\CompanySetupController;
use App\Http\Controllers\Api\HealthController;
use App\Http\Controllers\Api\UserAccessController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    Route::get('/health', HealthController::class);
    Route::get('/setup/status', [CompanySetupController::class, 'status']);
    Route::post('/setup/bootstrap', [CompanySetupController::class, 'bootstrap'])->middleware('throttle:auth');
    Route::post('/auth/login', [AuthController::class, 'login'])->middleware('throttle:auth');
    Route::post('/auth/invitations/accept', [UserAccessController::class, 'accept'])->middleware('throttle:auth');

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/auth/logout', [AuthController::class, 'logout']);
        Route::middleware('active.user')->group(function () {
            Route::get('/auth/me', [AuthController::class, 'me']);
            Route::get('/companies', [CompanyController::class, 'index']);
            Route::post('/companies/{company}/activate', [CompanyController::class, 'activate']);

            Route::middleware('company.context')->group(function () {
                Route::get('/context/company', [CompanyController::class, 'current']);
                Route::get('/settings/company', [CompanyProfileController::class, 'show'])->middleware('permission:settings.company.view');
                Route::patch('/settings/company', [CompanyProfileController::class, 'update'])->middleware('permission:settings.company.edit');
                Route::get('/settings/users', [UserAccessController::class, 'index'])->middleware('permission:settings.users.view');
                Route::get('/settings/users/roles', [UserAccessController::class, 'roles'])->middleware('permission:settings.users.view');
                Route::get('/settings/users/invitations', [UserAccessController::class, 'invitations'])->middleware('permission:settings.users.view');
                Route::post('/settings/users/invitations', [UserAccessController::class, 'invite'])->middleware('permission:settings.users.invite')->middleware('throttle:admin');
                Route::post('/settings/users/invitations/{invitation}/resend', [UserAccessController::class, 'resend'])->middleware('permission:settings.users.invite')->middleware('throttle:admin');
                Route::post('/settings/users/invitations/{invitation}/cancel', [UserAccessController::class, 'cancel'])->middleware('permission:settings.users.manage');
                Route::patch('/settings/users/{user}/role', [UserAccessController::class, 'changeRole'])->middleware('permission:settings.users.manage');
                Route::patch('/settings/users/{user}/status/{status}', [UserAccessController::class, 'changeStatus'])->middleware('permission:settings.users.manage');
                Route::get('/settings/activity', [UserAccessController::class, 'activity'])->middleware('permission:settings.activity.view');
            });
        });
    });
});
