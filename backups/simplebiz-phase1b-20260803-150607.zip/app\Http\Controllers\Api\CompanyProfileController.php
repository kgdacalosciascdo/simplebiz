<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Support\ApiResponse;
use App\Support\AuditService;
use App\Support\CompanyContext;
use App\Support\IdempotencyService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CompanyProfileController extends Controller
{
    public function __construct(private readonly CompanyContext $context, private readonly AuditService $audit, private readonly IdempotencyService $idempotency) {}

    public function show()
    {
        return ApiResponse::success($this->context->get());
    }

    public function update(Request $request)
    {
        $input = $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'legal_name' => ['nullable', 'string', 'max:180'],
            'primary_contact_name' => ['nullable', 'string', 'max:120'],
            'primary_contact_email' => ['nullable', 'email', 'max:255'],
            'primary_contact_phone' => ['nullable', 'string', 'max:40'],
            'principal_address' => ['nullable', 'array'],
            'currency' => ['required', 'string', 'size:3'],
            'timezone' => ['required', 'timezone'],
            'locale' => ['required', 'string', 'max:12'],
            'fiscal_year_start_month' => ['nullable', 'integer', 'between:1,12'],
        ]);

        return $this->idempotency->run($request, 'settings.company.update', $this->context->id(), function () use ($request, $input) {
            $company = $this->context->get();
            $before = $company->only(array_keys($input));
            DB::transaction(function () use ($request, $company, $input, $before) {
                $company->update([...$input, 'currency' => strtoupper($input['currency'])]);
                $this->audit->record($request, 'company.profile.updated', $company, $company->id, $before, $company->fresh()->only(array_keys($input)), null, 'Company profile updated', 'Company setup details were updated.');
            });

            return ApiResponse::success($company->fresh());
        });
    }
}
