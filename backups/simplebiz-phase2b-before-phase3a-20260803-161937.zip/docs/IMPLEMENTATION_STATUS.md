# SimpleBIZ implementation status

Updated: 3 August 2026

The documents in `docs/` are the final, approved, authoritative implementation baseline. This status document records the current as-built repository state and does not replace the MDS documents.

## Completed phases

### Phase 1A

- Laravel 12 backend preserved in `backend/`.
- React, Vite, and Tailwind frontend preserved in `web/`.
- PostgreSQL environment configuration established.
- Sanctum token authentication foundation added.
- Companies, memberships, roles, permissions, audit/activity, idempotency, and correlation foundations added.
- Shared React application shell and workspace routing added.

### Phase 1B

- Phase 1A authentication and company-context gaps hardened.
- Public unrestricted registration removed from the normal API route set.
- Initial setup is available only when no company exists.
- Initial setup creates the first company, protected Business Owner membership, minimum system roles, permissions, safe defaults, audit, and activity evidence atomically.
- Company profile viewing and editing implemented through Settings & Administration.
- Active company selection is membership-authorized and persisted as the user’s preferred company.
- Inactive users and unauthorized company access are rejected server-side.
- User invitation lifecycle implemented: create, resend, cancel, and accept.
- Invitation tokens are stored as SHA-256 hashes, expire, and are single-use.
- Users & Access membership lifecycle implemented: role change, activation, suspension, and deactivation with protected-owner rules.
- Administrative activity API and Settings frontend panels implemented.
- Idempotency applies to setup, company profile updates, invitations, invitation acceptance, role changes, and membership status transitions.
- Idempotent response storage removes access and invitation tokens before persistence.
- Frontend session restoration, protected routes, setup, Business Setup, Users & Access, company switching, API errors, and deferred Settings cards implemented.

### Phase 2A — Master Registries core

- Added the governed MDS-1000 registry vertical slice without starting transaction modules.
- Added normalized, company-scoped PostgreSQL tables for Business Partners, partner roles, contacts, addresses, categories, units of measure, products/services, external identifiers, and registry history.
- Registry records use stable UUID identities, company-scoped codes, status/effective dates, versions, actor fields, correlation/source fields, optimistic concurrency, and forward-only lifecycle changes.
- Business Partners are one shared identity with Customer, Supplier, and Payee roles; Customers and Suppliers are filtered views, not duplicate identities.
- Added active/effective lookup APIs, search, pagination, summary counts, quick-create endpoints, detail/history endpoints, and dependency-aware deactivation.
- Added exact-code conflict handling, probable-duplicate warnings with explicit override reasons, audit/activity evidence, idempotent creates and lifecycle actions, and tenant-isolated queries.
- Added server permission keys for registry view/search/history and Business Partner, Item, Category, and Unit CRUD/lifecycle actions. Owner and Administrator mappings are seeded; Member receives read/search/history access.
- Added the Master Registries workspace with Customers, Suppliers, Products & Services, Categories, Units, quick actions, summary cards, and honest deferred cards for registries owned by later modules.
- Added Phase 2A backend contract tests covering shared roles/history, duplicate override, product/service rules, dependency blocking, and company isolation.

### Phase 2B - Transaction-readiness reference registries

- Added company-scoped currencies, payment methods, payment terms, tax codes, account titles, expense categories, branches, warehouses, stock locations, and reason codes.
- Added forward-only lifecycle, effective-date filtering, stable UUIDs, versioned updates, audit/activity evidence, history, idempotency, permission keys, and tenant-isolated queries for each registry.
- Added safe reference lookups with domain, classification, branch, warehouse, and active/effective filters for downstream transaction forms.
- Added company default links for currency, branch, payment term, payment method, warehouse, stock location, expense category, and expense account title with active same-company validation and deactivation dependency protection.
- Backfilled supported existing company currency values into the currency registry without inventing unsupported currency identities.
- Added explicit dependency rules for expense-category/account-title mappings and branch/warehouse/location hierarchies. No cash-account, inventory-balance, stock-movement, expense-transaction, or tax-engine tables were added.
- Added Phase 2B reference registry pages and quick-create forms to the Master Registries workspace. Cash account profiles remain delegated to MDS-700.
- Added focused Phase 2B backend tests for currency defaults, payment directions/terms, tax rates, expense mappings, location hierarchy, reason-code lookups, and scope boundaries.

## PostgreSQL and migrations

The backend uses `pgsql` through environment configuration. The local PostgreSQL migration status was verified, and the Phase 2B migrations `2026_08_03_000008_create_transaction_reference_registries` and `2026_08_03_000009_seed_reference_registries` were applied with the normal `php artisan migrate` command. No reset or destructive migration command was used.

Required local configuration is kept in `backend/.env` and must not be committed. New environments should copy `backend/.env.example`, set a valid PostgreSQL database and credentials, and run:

```powershell
php artisan config:clear
php artisan cache:clear
php artisan migrate
```

## Authentication and access behavior

- Login is rate-limited and issues an expiring Sanctum token.
- Logout revokes the current token.
- Current-user access is protected by Sanctum and active-user middleware.
- Suspended or deactivated users cannot use ordinary protected routes.
- Initial owner bootstrap is setup-gated and rate-limited.
- Ordinary account creation occurs through a company invitation acceptance flow.
- Passwords, tokens, invitation tokens, and secrets are excluded from normal API payloads, audit metadata, and idempotency replay storage.

## API endpoints

- `GET /api/v1/health`
- `GET /api/v1/setup/status`
- `POST /api/v1/setup/bootstrap`
- `POST /api/v1/auth/login`
- `POST /api/v1/auth/logout`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/invitations/accept`
- `GET /api/v1/companies`
- `POST /api/v1/companies/{company}/activate`
- `GET /api/v1/context/company`
- `GET|PATCH /api/v1/settings/company`
- `GET /api/v1/settings/users`
- `GET /api/v1/settings/users/roles`
- `GET /api/v1/settings/users/invitations`
- `POST /api/v1/settings/users/invitations`
- `POST /api/v1/settings/users/invitations/{invitation}/resend`
- `POST /api/v1/settings/users/invitations/{invitation}/cancel`
- `PATCH /api/v1/settings/users/{user}/role`
- `PATCH /api/v1/settings/users/{user}/status/{status}`
- `GET /api/v1/settings/activity`
- `GET /api/v1/master-registries`
- `GET /api/v1/master-registries/lookups`
- `GET|POST /api/v1/master-registries/business-partners`
- `POST /api/v1/master-registries/business-partners/quick-create`
- `GET|PATCH /api/v1/master-registries/business-partners/{id}`
- `POST /api/v1/master-registries/business-partners/{id}/deactivate`
- `POST /api/v1/master-registries/business-partners/{id}/reactivate`
- `GET /api/v1/master-registries/business-partners/{id}/history`
- `POST /api/v1/master-registries/business-partners/{id}/contacts`
- `POST /api/v1/master-registries/business-partners/{id}/addresses`
- `GET|POST /api/v1/master-registries/products-services`
- `POST /api/v1/master-registries/products-services/quick-create`
- `GET|PATCH /api/v1/master-registries/products-services/{id}`
- `POST /api/v1/master-registries/products-services/{id}/deactivate|reactivate`
- `GET /api/v1/master-registries/products-services/{id}/history`
- `GET|POST /api/v1/master-registries/categories`
- `GET|PATCH /api/v1/master-registries/categories/{id}`
- `POST /api/v1/master-registries/categories/{id}/deactivate|reactivate`
- `GET /api/v1/master-registries/categories/{id}/history`
- `GET|POST /api/v1/master-registries/units`
- `GET|PATCH /api/v1/master-registries/units/{id}`
- `POST /api/v1/master-registries/units/{id}/deactivate|reactivate`
- `GET /api/v1/master-registries/units/{id}/history`
- `GET /api/v1/master-registries/reference-lookups`
- `GET|POST /api/v1/master-registries/currencies`
- `GET|PATCH /api/v1/master-registries/currencies/{id}`
- `POST /api/v1/master-registries/currencies/{id}/deactivate|reactivate`
- `GET /api/v1/master-registries/currencies/{id}/history`
- The same list/detail/create/update/lifecycle/history contract is available for `payment-methods`, `payment-terms`, `tax-codes`, `account-titles`, `expense-categories`, `branches`, `warehouses`, `stock-locations`, and `reason-codes`.

All administrative responses use the shared `data`/`meta` success envelope or `message`/`errors` error envelope and include `X-Correlation-ID`.

## Frontend routes

- `/login`
- `/setup`
- `/preview`
- `/settings`
- `/settings/business-setup`
- `/settings/users-access`
- `/master-registries`
- `/master-registries/business-partners`
- `/master-registries/business-partners/new`
- `/customers`
- `/suppliers`
- `/products-services`
- `/products-services/new`
- `/categories`
- `/units`
- `/master-registries?registry=currencies`
- `/master-registries?registry=payment-methods`
- `/master-registries?registry=payment-terms`
- `/master-registries?registry=tax-codes`
- `/master-registries?registry=account-titles`
- `/master-registries?registry=expense-categories`
- `/master-registries?registry=branches`
- `/master-registries?registry=warehouses`
- `/master-registries?registry=stock-locations`
- `/master-registries?registry=reason-codes`
- Existing module routes remain visual foundations only; transaction posting is not implemented.

## Testing

Backend coverage includes setup, idempotency replay safety, login, protected routes, company context, invitations, owner protection, permission enforcement, correlation IDs, validation envelopes, shared partner roles/history, duplicate handling, item integrity rules, dependency blocking, tenant isolation, and Phase 2B reference registry rules. The current backend suite is 19 passing tests, 1 intentionally skipped PostgreSQL-only schema test, and 74 assertions. Frontend coverage includes protected-route redirect, workspace preview, token/company storage, API headers, safe API errors, and Phase 2B registry rendering.

## Deferred scope

The following remain intentionally deferred: full custom roles, complete permission administration UI, subscription billing and entitlements, MFA, notification administration, numbering configuration, approval-policy builder, richer tax/accounting configuration, integrations, UOM conversions, merge/import tooling, and all transaction modules.

Phase 2A and Phase 2B intentionally do not implement Sales, Collections, Cash Accounts, Inventory movements/balances, Purchases, Expenses, Payments, Reports, price lists, tax engines, bundles, or transaction-specific customer/supplier ledgers.

No Master Registry CRUD or transaction module was started in Phase 1B.

## Known limitations

- Mail delivery is not configured; invitations record `not_configured` or the configured development delivery status and do not pretend that an email was delivered.
- The frontend currently stores the Sanctum token in browser local storage because Phase 1A established token-based API authentication. A future deployment decision may move this to a cookie-based Sanctum SPA flow with CSRF protection.
- Full permission administration and custom role design remain deferred.
- The local PHP runtime does not have the `intl` extension enabled; `php artisan db:show` connects successfully but exits while formatting table counts. Migration status and migration execution remain successful.

## Recommended next phase

The recommended next phase is MDS-700 Cash Accounts Profile and Opening Balance Foundation, limited to cash account profiles, company linkage, opening-balance foundation, lifecycle, audit/history, and permission enforcement. Do not add cash movements, reconciliation, balances, settlement logic, or report semantics until that scope is explicitly approved. Transaction modules should consume these reference identities rather than recreate them.
