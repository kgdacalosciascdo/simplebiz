<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\BusinessPartnerController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\CompanyController;
use App\Http\Controllers\Api\CompanyProfileController;
use App\Http\Controllers\Api\CompanySetupController;
use App\Http\Controllers\Api\HealthController;
use App\Http\Controllers\Api\MasterRegistryController;
use App\Http\Controllers\Api\ProductServiceController;
use App\Http\Controllers\Api\UnitController;
use App\Http\Controllers\Api\UserAccessController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    Route::get('/health', HealthController::class);
    Route::get('/setup/status', [CompanySetupController::class, 'status']);
    Route::post('/setup/bootstrap', [CompanySetupController::class, 'bootstrap'])->middleware('throttle:auth');
    Route::post('/auth/login', [AuthController::class, 'login'])->middleware('throttle:auth');
    Route::post('/auth/invitations/accept', [UserAccessController::class, 'accept'])->middleware('throttle:auth');

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/auth/logout', [AuthController::class, 'logout']);
        Route::middleware('active.user')->group(function () {
            Route::get('/auth/me', [AuthController::class, 'me']);
            Route::get('/companies', [CompanyController::class, 'index']);
            Route::post('/companies/{company}/activate', [CompanyController::class, 'activate']);

            Route::middleware('company.context')->group(function () {
                Route::get('/context/company', [CompanyController::class, 'current']);
                Route::get('/settings/company', [CompanyProfileController::class, 'show'])->middleware('permission:settings.company.view');
                Route::patch('/settings/company', [CompanyProfileController::class, 'update'])->middleware('permission:settings.company.edit');
                Route::get('/settings/users', [UserAccessController::class, 'index'])->middleware('permission:settings.users.view');
                Route::get('/settings/users/roles', [UserAccessController::class, 'roles'])->middleware('permission:settings.users.view');
                Route::get('/settings/users/invitations', [UserAccessController::class, 'invitations'])->middleware('permission:settings.users.view');
                Route::post('/settings/users/invitations', [UserAccessController::class, 'invite'])->middleware('permission:settings.users.invite')->middleware('throttle:admin');
                Route::post('/settings/users/invitations/{invitation}/resend', [UserAccessController::class, 'resend'])->middleware('permission:settings.users.invite')->middleware('throttle:admin');
                Route::post('/settings/users/invitations/{invitation}/cancel', [UserAccessController::class, 'cancel'])->middleware('permission:settings.users.manage');
                Route::patch('/settings/users/{user}/role', [UserAccessController::class, 'changeRole'])->middleware('permission:settings.users.manage');
                Route::patch('/settings/users/{user}/status/{status}', [UserAccessController::class, 'changeStatus'])->middleware('permission:settings.users.manage');
                Route::get('/settings/activity', [UserAccessController::class, 'activity'])->middleware('permission:settings.activity.view');

                Route::prefix('master-registries')->group(function () {
                    Route::get('/', [MasterRegistryController::class, 'summary'])->middleware('permission:master-registries.view');
                    Route::get('/lookups', [MasterRegistryController::class, 'lookups'])->middleware('permission:master-registries.search');

                    Route::get('/business-partners', [BusinessPartnerController::class, 'index'])->middleware('permission:master-registries.business-partners.view');
                    Route::post('/business-partners', [BusinessPartnerController::class, 'store'])->middleware('permission:master-registries.business-partners.create');
                    Route::post('/business-partners/quick-create', [BusinessPartnerController::class, 'quickCreate'])->middleware('permission:master-registries.business-partners.create');
                    Route::get('/business-partners/{businessPartner}', [BusinessPartnerController::class, 'show'])->middleware('permission:master-registries.business-partners.view');
                    Route::patch('/business-partners/{businessPartner}', [BusinessPartnerController::class, 'update'])->middleware('permission:master-registries.business-partners.update');
                    Route::post('/business-partners/{businessPartner}/deactivate', [BusinessPartnerController::class, 'deactivate'])->middleware('permission:master-registries.business-partners.deactivate');
                    Route::post('/business-partners/{businessPartner}/reactivate', [BusinessPartnerController::class, 'reactivate'])->middleware('permission:master-registries.business-partners.reactivate');
                    Route::get('/business-partners/{businessPartner}/history', [BusinessPartnerController::class, 'history'])->middleware('permission:master-registries.history');
                    Route::post('/business-partners/{businessPartner}/contacts', [BusinessPartnerController::class, 'contact'])->middleware('permission:master-registries.business-partners.update');
                    Route::post('/business-partners/{businessPartner}/addresses', [BusinessPartnerController::class, 'address'])->middleware('permission:master-registries.business-partners.update');

                    Route::get('/products-services', [ProductServiceController::class, 'index'])->middleware('permission:master-registries.items.view');
                    Route::post('/products-services', [ProductServiceController::class, 'store'])->middleware('permission:master-registries.items.create');
                    Route::post('/products-services/quick-create', [ProductServiceController::class, 'quickCreate'])->middleware('permission:master-registries.items.create');
                    Route::get('/products-services/{productService}', [ProductServiceController::class, 'show'])->middleware('permission:master-registries.items.view');
                    Route::patch('/products-services/{productService}', [ProductServiceController::class, 'update'])->middleware('permission:master-registries.items.update');
                    Route::post('/products-services/{productService}/deactivate', [ProductServiceController::class, 'deactivate'])->middleware('permission:master-registries.items.deactivate');
                    Route::post('/products-services/{productService}/reactivate', [ProductServiceController::class, 'reactivate'])->middleware('permission:master-registries.items.reactivate');
                    Route::get('/products-services/{productService}/history', [ProductServiceController::class, 'history'])->middleware('permission:master-registries.history');

                    Route::get('/categories', [CategoryController::class, 'index'])->middleware('permission:master-registries.categories.view');
                    Route::post('/categories', [CategoryController::class, 'store'])->middleware('permission:master-registries.categories.create');
                    Route::get('/categories/{category}', [CategoryController::class, 'show'])->middleware('permission:master-registries.categories.view');
                    Route::patch('/categories/{category}', [CategoryController::class, 'update'])->middleware('permission:master-registries.categories.update');
                    Route::post('/categories/{category}/deactivate', [CategoryController::class, 'deactivate'])->middleware('permission:master-registries.categories.deactivate');
                    Route::post('/categories/{category}/reactivate', [CategoryController::class, 'reactivate'])->middleware('permission:master-registries.categories.reactivate');
                    Route::get('/categories/{category}/history', [CategoryController::class, 'history'])->middleware('permission:master-registries.history');

                    Route::get('/units', [UnitController::class, 'index'])->middleware('permission:master-registries.units.view');
                    Route::post('/units', [UnitController::class, 'store'])->middleware('permission:master-registries.units.create');
                    Route::get('/units/{unit}', [UnitController::class, 'show'])->middleware('permission:master-registries.units.view');
                    Route::patch('/units/{unit}', [UnitController::class, 'update'])->middleware('permission:master-registries.units.update');
                    Route::post('/units/{unit}/deactivate', [UnitController::class, 'deactivate'])->middleware('permission:master-registries.units.deactivate');
                    Route::post('/units/{unit}/reactivate', [UnitController::class, 'reactivate'])->middleware('permission:master-registries.units.reactivate');
                    Route::get('/units/{unit}/history', [UnitController::class, 'history'])->middleware('permission:master-registries.history');
                });
            });
        });
    });
});
